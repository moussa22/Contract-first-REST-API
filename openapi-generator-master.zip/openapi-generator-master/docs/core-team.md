---
id: core-team
title: Core Team Members
---

* [@wing328](https://github.com/wing328) (2015/07)
* [@jimschubert](https://github.com/jimschubert) (2016/05)
* [@cbornet](https://github.com/cbornet) (2016/05)
* [@jaz-ah](https://github.com/jaz-ah) (2016/05)
* [@ackintosh](https://github.com/ackintosh) (2018/02)
* [@JFCote](https://github.com/JFCote) (2018/03)
* [@jmini](https://github.com/jmini) (2018/04)